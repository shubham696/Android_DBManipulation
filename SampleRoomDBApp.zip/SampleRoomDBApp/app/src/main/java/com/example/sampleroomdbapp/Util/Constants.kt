package com.example.sampleroomdbapp.Util

object Constants {
    const val TABLE_NAME_NOTE = "Todo Note"
    const val DB_NAME = "notesdb.db"
}