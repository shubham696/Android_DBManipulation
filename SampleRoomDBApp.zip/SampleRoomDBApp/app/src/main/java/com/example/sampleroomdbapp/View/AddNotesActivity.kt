package com.example.sampleroomdbapp.View

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class AddNotesActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

}
