package com.example.sampleroomdbapp

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.sampleroomdbapp.Model.Note
import com.example.sampleroomdbapp.Util.Constants
import com.example.sampleroomdbapp.dao.NoteDao

@Database(entities = [Note::class],version = 1)
abstract class AppDatabase: RoomDatabase() {

    abstract fun getNoteDao(): NoteDao

    private var appDatabase: AppDatabase? = null

    fun getInstance(context: Context): AppDatabase{
        if(null == appDatabase){
            appDatabase = buildDataBaseInstant(context)
        }
        return appDatabase!!
    }

    private fun buildDataBaseInstant(context: Context): AppDatabase {
        return Room.databaseBuilder<AppDatabase>(context,AppDatabase::class.java,Constants.DB_NAME)
            .allowMainThreadQueries()
            .build()
    }

    fun cleanUpDb(){
        appDatabase = null
    }
}