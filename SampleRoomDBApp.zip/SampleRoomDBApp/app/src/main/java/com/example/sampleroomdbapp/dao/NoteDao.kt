package com.example.sampleroomdbapp.dao

import androidx.room.*
import com.example.sampleroomdbapp.Model.Note
import com.example.sampleroomdbapp.Util.Constants

@Dao
public abstract class NoteDao{

    @Query("SELECT * FROM  user"+ Constants.TABLE_NAME_NOTE)
    abstract fun getAll(): List<Note>

    @Insert
    abstract fun insert(note: Note)

    @Update
    abstract fun update(note: Note)

    @Delete
    abstract fun delete(note: Note)

    @Delete
    abstract fun delete(vararg note: Note)

}